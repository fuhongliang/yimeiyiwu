<div class="page">
  <table class="table tb-type2">
    <thead>
      <tr class="space">
        <th colspan="10" class="nobg big">关于我们</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td class="w12"></td>
        <td>欢迎使用【好商城V4-33hao】程序，祝君生意兴隆。<a href="http://bbs.33hao.com?v4" title="技术支持" target="_blank">技术支持</a></td>
      </tr>
    </tbody><tfoot>
      <tr class="tfoot">
        <td colspan="10"></td>
      </tr>
    </tfoot>
  </table>
