<?php
/**
 * 手机首页
 *
 *
 *
 *
 * by 33hao www.33hao.com 开发修正
 */



defined('InShopNC') or exit('Access Invalid!');
class mb_indexControl extends SystemControl{
	public function __construct(){
		parent::__construct();
	}

    /**
     * 首页项目列表
     */
    public function index_listOp() {
    }
}

