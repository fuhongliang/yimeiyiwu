<?php
defined('InShopNC') or exit('Access Invalid!');

/**
 * 意見反饋
 */
$lang['feedback_mange_title'] 	= '意見反饋';
$lang['feedback_del_succ'] 		= '刪除成功';
$lang['feedback_del_fiald'] 	= '刪除失敗';
$lang['feedback_index_content'] = '反饋內容';
$lang['feedback_index_time'] 	= '時間';
$lang['feedback_index_from'] 	= '來自';

?>