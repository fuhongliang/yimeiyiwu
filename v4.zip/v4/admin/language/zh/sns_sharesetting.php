<?php
defined('InShopNC') or exit('Access Invalid!');
$lang['shareset_list_tip'] 		= '開啟並設置以下介面配置信息後，SNS分享店舖和商品信息功能中將可以使用站外分享信息功能';
$lang['shareset_list_appname'] 		= '應用名稱';
$lang['shareset_list_appurl'] 		= '網址';
$lang['shareset_list_appstate'] 	= '啟用狀態';
$lang['shareset_list_closeprompt'] 	= '確認要關閉該介面嗎？';


$lang['shareset_edit_title'] 		= '介面設置';
$lang['shareset_edit_appisuse'] 	= '是否啟用該介面';
$lang['shareset_edit_appcode'] 		= '域名驗證信息';
$lang['shareset_edit_appid'] 		= '應用標識';
$lang['shareset_edit_applylike'] 		= '立即在綫申請';
$lang['shareset_edit_appkey'] 		= '應用密鑰';