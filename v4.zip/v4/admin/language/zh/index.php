<?php
defined('InShopNC') or exit('Access Invalid!');

/**
 * 修改密碼
 */
$lang['index_modifypw_repeat_error']		= '兩次輸入的密碼不一致，請重新輸入';
$lang['index_modifypw_admin_error']			= '管理員信息錯誤';
$lang['index_modifypw_oldpw_error']			= '原密碼錯誤';
$lang['index_modifypw_success']				= '密碼設置成功';
$lang['index_modifypw_fail']				= '密碼設置失敗';
$lang['index_modifypw_oldpw']				= '原密碼';
$lang['index_modifypw_newpw']				= '新密碼';
$lang['index_modifypw_newpw2']				= '確認密碼';