<?php
defined('InShopNC') or exit('Access Invalid!');

//common.php 调用

$lang['nc_comm_workarea']	=  '工作区域';
$lang['nc_comm_cut_view']	=  '裁切预览';
$lang['nc_comm_op_help']	=  '操作帮助';
$lang['nc_comm_op_help_tip']=  '请在工作区域放大缩小及移动选取框，选择要裁剪的范围，裁切宽高比例固定；裁切后的效果为右侧预览图所显示；保存提交后生效。';