<?php
defined('InShopNC') or exit('Access Invalid!');
/**
 * 图片空间
 */
$lang['g_album_manage']			= '图片空间';
$lang['g_album_list']			= '相册列表';
$lang['g_album_pic_list']		= '图片列表';
$lang['g_album_keyword']		= '请输入店铺ID或完整名称';
$lang['g_album_del_tips']		= '相册删除后，相册内全部图片都会删除，不能恢复，请谨慎操作';
$lang['g_album_fmian']			= '封面';
$lang['g_album_one']			= '相册';
$lang['g_album_shop']			= '店铺';
$lang['g_album_pic_count']		= '图片数';
$lang['g_album_pic_one']		= '图片';
$lang['g_album_manage']			= '图片空间';
$lang['g_album_manage']			= '图片空间';