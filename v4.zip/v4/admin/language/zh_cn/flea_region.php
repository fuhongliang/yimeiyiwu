<?php
defined('InShopNC') or exit('Access Invalid!');

$lang['flea_index_setting']     = '閒置頁面設置';
$lang['flea_index_seo_setting'] = 'SEO設置';
$lang['flea_site_name']         = '閒置首頁名稱';
$lang['flea_site_title']        = '閒置首頁標題';
$lang['flea_site_description']  = '閒置首頁描述';
$lang['flea_site_keywords']     = '閒置首頁關鍵字';
$lang['flea_hot_search']        = '閒置首頁熱門搜索';

$lang['flea_isuse_off_tips']    = '閒置市場功能未開啟';
